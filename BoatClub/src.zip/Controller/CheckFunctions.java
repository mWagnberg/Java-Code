package Controller;

import Model.Boat;
import Model.Member;

import java.util.regex.Pattern;

/**
 * Created by Michael on 2016-11-01.
 */
public class CheckFunctions extends BoatClubRegistry
{
    /**
     * This will check if the user choose the "right" boat type
     * @param boatType is the integer that will be checked
     * @return false if the user types in something below 1 and something above 4,
     * otherwise true
     */
    public boolean checkAlternative(int boatType)
    {
        if(boatType > 4 || boatType < 1)
        {
            return false;
        }

        return true;
    }

    /**
     * This will check if the user choose the "right" choice
     * @param boatChange is the integer that will be checked
     * @return false if the user types in something below 1 and something above 2,
     * otherwise true
     */
    public boolean checkAlternativeInTwoWays(int boatChange)
    {
        if(boatChange > 2 || boatChange < 1)
        {
            return false;
        }

        return true;
    }

    /**
     * This will check if a String only contains letters and whitespaces
     * @param str is the String that will be checked
     * @return true if the String only contains letters and whitespaces,
     * otherwise false
     */
    public boolean checkLetters(String str)
    {
        if(Pattern.matches("[a-z A-Z,.<>]+",str))
        {
            return true;
        }

        return false;
    }

    /**
     * This will check if a member exist in the register
     * @param str is the id of the member that will be checked
     * @return true if the member exist in the register, otherwise false
     */
    public boolean checkIfMemberExist(String str)
    {
        loadMemberFile();
        int n = Integer.parseInt(str);

        for(int i = 0; i < memberList.size(); i++)
        {
            if(n == memberList.get(i).getId())
            {
                return true;
            }
        }

        return false;
    }

    /**
     * This will check if a member exist in the register
     * @param str is the id of the member that will be checked
     * @return true if the member exist in the register, otherwise false
     */
    public boolean checkIfBoatExist(String str)
    {
        loadBoatFile();
        int n = Integer.parseInt(str);

        for(int i = 0; i < boatList.size(); i++)
        {
            if(n == boatList.get(i).getBoatId())
            {
                return true;
            }
        }

        return false;
    }

    /**
     * This prints out the list of boats
     * @return a StringBuilder containing a list of boats
     */
    public StringBuilder printBoatList()
    {
        loadBoatFile();
        StringBuilder str = new StringBuilder();

        for(Boat b : boatList)
        {
            str.append(b.getBoatId() + " - " + b.getBoatOwnerId() + " | ");
        }

        return str;
    }

    /**
     * This prints out the list of members
     * @return a StringBuilder containing a list of members
     */
    public StringBuilder printMemberList()
    {
        loadMemberFile();
        StringBuilder str = new StringBuilder();

        for(Member member : memberList)
        {
            str.append(member.getId() + " - " + member.getName());
        }

        return str;
    }
}
