package Controller;

import Model.Boat;
import Model.Member;
import View.Console;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by Michael Wagnberg and Patrik Hermansson on 2016-09-27.
 *
 * This class contains all the functions needed to handle a boat club.
 * Add, change and delete a member
 * Add, change and delete a boat
 * Show compact and verbose list over members
 * Look at a specific members information
 */
public class BoatClubRegistry
{
    /**
     * Create fields
     */
    private String memberPath = ".\\src\\members.txt";
    private String boatPath = ".\\src\\boats.txt";
    private File memberFile = new File(memberPath);
    private File boatFile = new File(boatPath);
    ArrayList<Member> memberList = new ArrayList();
    ArrayList<Boat> boatList = new ArrayList<>();
    private Member m = new Member();

    /**
     * This will add a member to the member file
     * @param name is the name of the new member
     * @param ssn is the personal security number of the new member
     */
    public void addMember(String name, String ssn)
    {
        try
        {
            // Create a PrintWriter object that holds the file containing the members
            PrintWriter printer = new PrintWriter(new FileOutputStream(new File(memberPath),true));

            /*If the file is empty the first member gets 1000 as an id,
             * otherwise it loops through the list of members and the new members gets
             * the id one over the last member, and then save the name */
            if(memberFile.length() == 0)
            {
                m.setIdCounter(1000);
            }
            else
            {
                loadMemberFile();

                for (Member member : memberList)
                {
                    if (member.getId() > member.getIdCounter())
                    {
                        int test = member.getId() + 1;
                        m.setIdCounter(test);
                    }
                }
            }

            System.out.println(name + " with ID " + m.getIdCounter() + " added");

            // Save the member to the file
            printer.print(name + "," + ssn + "," + m.getIdCounter());
            printer.print("\n");
            printer.close();
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * This will show a specific members information; Name, SSN, ID and Boats
     * @param input is the ID of the member that will be searched for
     */
    public void searchName(String input)
    {
        loadMemberFile();
        String answer = "";
        int inputValue = Integer.parseInt(input);

        /* When loading the file of members the list of members now contains all the members,
         * when a members ID matches with the wanted ID it will fill a string with the information*/
        for(Member member : memberList)
        {
            if(member.getId() == inputValue)
            {
                answer = member.getName() + " has social security number: " + member.getSocialSecurityNumber() + ", ID " + member.getId() + "\n" +
                        "Boats: \n" + member.getBoatBelonging();
            }
        }

        // Print the information
        System.out.println(answer);

    }

    /**
     * This will delete a member and its appurtenant boats
     * @param id is the id of the member that will be deleted
     */
    public void deleteMember(String id)
    {

        loadMemberFile();
        int memberId = Integer.parseInt(id);
        /* When loading the file of members the list of members now contains all the members,
        * when a members ID matches with the wanted ID the member will be deleted from the list*/
        for(int i = 0; i < memberList.size(); i++)
        {
            if(memberId == memberList.get(i).getId())
            {
                memberList.remove(i);
            }
        }
        if(boatFile.exists())
        {
            /* This will read the file containing boats and delete the boat/boats that
             * belongs to the member who's gonna be deleted*/
            try
            {
                boatList = new ArrayList<>();

                Scanner inBoat = new Scanner(boatFile);

                while(inBoat.hasNext())
                {
                    Boat b = new Boat();
                    String boatData = inBoat.nextLine();
                    String[] boatValues = boatData.split(",");
                    b.setBoatType(boatValues[1]);
                    b.setBoatLength(Integer.parseInt(boatValues[2]));
                    b.setBoatOwnerId(Integer.parseInt(boatValues[0]));
                    b.setBoatId(Integer.parseInt((boatValues[3])));

                    boatList.add(b);

                    for(int i = 0; i < boatList.size(); i++)
                    {
                        if(memberId == boatList.get(i).getBoatOwnerId())
                        {
                            boatList.remove(i);
                        }
                    }
                }
            }
            catch (FileNotFoundException e)
            {
                e.printStackTrace();
            }

            saveBoatFile();
        }

        saveMemberFile();

        System.out.println("Member with ID " + id + " deleted");
    }

    /**
     * This will change a members information
     * @param id is the ID of the member that will be changed
     * @param answerChange is either 1 or 2, depending on what the member choose
     * @param newInfo is the new name or the new ssn
     */
    public void changeMember(String id, int answerChange, String newInfo)
    {
        loadMemberFile();
        int memberId = Integer.parseInt(id);

        /* If the member chooses to change the name it will loop through the
         * list of members and set the new name */
        if(answerChange == 1)
        {
            for(int i = 0; i < memberList.size(); i++)
            {
                if(memberId == memberList.get(i).getId())
                {
                    memberList.get(i).setName(newInfo);
                }
            }
        }

        /* Otherwise the member chooses to change the ssn and it will loop through the
         * list of members and set the new ssn */
        else if(answerChange == 2)
        {
            for(int i = 0; i < memberList.size(); i++)
            {
                if (memberId == memberList.get(i).getId())
                {
                    memberList.get(i).setSocialSecurityNumber(newInfo);
                }
            }
        }

        // Save the changes to the member file
        saveMemberFile();
    }

    /**
     * This will add a boat to a member
     * @param boatOwner is the ID of the member that wants to add a boat
     * @param boatType is 1, 2, 3 or 4, depending of what the member has chosen
     * @param boatLength is the length of the boat
     */
    public void addBoat(String boatOwner, int boatType, String boatLength)
    {
        // Create a new Boat object
        Boat b = new Boat();
        int length = Integer.parseInt(boatLength);
        int owner = Integer.parseInt(boatOwner);

        try
        {
            // Create a PrintWriter object that holds the file containing the boats
            PrintWriter printer = new PrintWriter(new FileOutputStream(new File(boatPath),true));

            // Save the ID of the member that owns the boat
            printer.print(owner + ",");

            /* Depending on what the member has chosen what kind of boat
             * the actually boat type saves into the file */
            if(boatType == 1)
            {
                printer.print("Sailboat");
                System.out.print("Sailboat with ID ");
            }
            else if(boatType == 2)
            {
                printer.print("Motorsailer");
                System.out.print("Motorsailer with ID ");
            }
            else if(boatType == 3)
            {
                printer.print("Kayak/Canoe");
                System.out.print("Kayak/Canoe with ID ");
            }
            else if(boatType== 4)
            {
                printer.print("Other");
                System.out.print("Other with ID ");
            }

            /* If the file is empty, the first boat gets a ID 5000
             * otherwise it loops through the list of boats and the new boat gets
             * the id one over the last boat */
            if (boatFile.length() == 0)
            {
                b.setBoatCounter(5000);
            }
            else
            {
                Scanner scan = new Scanner(boatFile);

                while(scan.hasNext())
                {
                    Boat boat1 = new Boat();
                    String data = scan.nextLine();
                    String[] boatarray = data.split(",");
                    boat1.setBoatOwnerId(Integer.parseInt(boatarray[0]));
                    boat1.setBoatType(boatarray[1]);
                    boat1.setBoatLength(Integer.parseInt(boatarray[2]));
                    boat1.setBoatId(Integer.parseInt(boatarray[3]));

                    boatList.add(boat1);

                }

                for (Boat boatcount : boatList)
                {
                    if (boatcount.getBoatId() > boatcount.getBoatCounter())
                    {
                        int b1 = boatcount.getBoatId()+1;
                        b.setBoatCounter(b1);
                    }
                }
            }

            System.out.println(b.getBoatCounter() + " added");

            // Save the length and the boat id to the file
            printer.print("," + length);
            printer.print("," + b.getBoatCounter() + "\n");
            printer.close();
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * This will delete a boat
     * @param boatId is the boat that will be deleted
     */
    public void deleteBoat(String boatId)
    {
        loadBoatFile();
        int id = Integer.parseInt(boatId);

        // Loop through the boat list and delete the boat that match with the wanted
        for(int i = 0; i < boatList.size(); i++)
        {
            if(id == boatList.get(i).getBoatId())
            {
                boatList.remove(i);
            }
        }

        saveBoatFile();

        System.out.println("Boat with ID " + boatId + " deleted");
    }

    /**
     * This will change a boats information; Boat type or length
     * @param boatId is the id af the boat
     * @param answerChange is 1 or 2; Boat type or length
     * @param newInfo is the new Boat type or length
     */
    public void changeBoat(String boatId, int answerChange, int newInfo)
    {
        loadBoatFile();
        int id = Integer.parseInt(boatId);

        /* This will happen if member chooses to change the boat type
         * and depending on what the member has chosen regarding the boat type
         * the specific boat type will be set */
        if(answerChange == 1)
        {
            if(newInfo == 1)
            {
                for(int i = 0; i < boatList.size(); i++)
                {
                    if(id == boatList.get(i).getBoatId())
                    {
                        boatList.get(i).setBoatType("Sailboat");
                    }
                }
            }

            else if(newInfo == 2)
            {
                for(int i = 0; i < boatList.size(); i++)
                {
                    if(id == boatList.get(i).getBoatId())
                    {
                        boatList.get(i).setBoatType("Motorsailer");
                    }
                }
            }

            else if(newInfo == 3)
            {
                for(int i = 0; i < boatList.size(); i++)
                {
                    if(id == boatList.get(i).getBoatId())
                    {
                        boatList.get(i).setBoatType("Kayak/Canoe");
                    }
                }
            }

            else if(newInfo == 4)
            {
                for(int i = 0; i < boatList.size(); i++)
                {
                    if(id == boatList.get(i).getBoatId())
                    {
                        boatList.get(i).setBoatType("Other");
                    }
                }
            }
        }

        /* This will happen if member chooses to change the boat length
         * and the length will be set */
        if (answerChange == 2)
        {
            for(int i = 0; i < boatList.size(); i++)
            {
                if (id == boatList.get(i).getBoatId())
                {
                    boatList.get(i).setBoatLength(newInfo);
                }
            }
        }

        // Save the changes to the file
        saveBoatFile();

        System.out.println("Boat with ID " + boatId + " changed");
    }

    /**
     * This will load the file containing members and fill the list of members
     */
    public void loadMemberFile()
    {
        Console c = new Console();

        if(!memberFile.exists())
        {
            System.out.println("No member registered");
            c.showMainMenu();
        }
        else
        {
            memberList = new ArrayList<>();

            try
            {
                // Create a Scanner object that holds the file containing members
                Scanner in = new Scanner(memberFile);

                // This will loop as long there is something in the file
                while(in.hasNext())
                {
                /* Create a new member object and a String array that is separated by ","
                 * The array stores all the information on the relevant element */
                    Member member = new Member();
                    String data = in.nextLine();
                    String[] values = data.split(",");
                    member.setName(values[0]);
                    member.setSocialSecurityNumber(values[1]);
                    member.setId(Integer.parseInt(values[2]));

                    if(boatFile.exists())
                    {
                        // Create a Scanner object that holds the file containing boats
                        Scanner inBoat = new Scanner(boatFile);
                        boatList = new ArrayList<>();

                        String boatToMember = "";

                        // This will loop as long as there is something in the file
                        while(inBoat.hasNext())
                        {
                    /* Create a new member object and a String array that is separated by ","
                     * The array stores all the information on the relevant element */
                            Boat b = new Boat();
                            String boatData = inBoat.nextLine();
                            String[] boatValues = boatData.split(",");
                            b.setBoatOwnerId(Integer.parseInt(boatValues[0]));
                            b.setBoatType(boatValues[1]);
                            b.setBoatLength(Integer.parseInt(boatValues[2]));
                            b.setBoatId(Integer.parseInt(boatValues[3]));

                            // This checks if a specific member has a belonging boat
                            if(b.getBoatOwnerId() == member.getId())
                            {
                                boatToMember += "- " + b.getBoatId() + " " + b.getBoatType() + " - " + b.getBoatLength() + " m\n";
                                boatList.add(b);
                            }
                            member.setBoatList(boatList);
                        }
                        member.setBoatBelonging(boatToMember);
                    }

                    memberList.add(member);
                }
            }
            catch (FileNotFoundException e)
            {
                e.printStackTrace();
            }
        }
    }

    /**
     * This will save all the members to the file that contains members
     */
    private void saveMemberFile()
    {
        try
        {
            // Create a PrintWriter object that hold the file containing members
            PrintWriter printer = new PrintWriter(new FileOutputStream(new File(memberPath),false));

            // Iterate over the list and save the members info to the file
            for(Member member : memberList)
            {
                printer.print(member.getName() + "," + member.getSocialSecurityNumber() + "," + member.getId() + "\n");
            }
            printer.close();
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * This will load the file containing boats and fill the list of boats
     */
    public void loadBoatFile()
    {
        Console c = new Console();

        if(!boatFile.exists())
        {
            System.out.println("No boats registered");
            c.showMainMenu();
        }

        else
        {
            boatList = new ArrayList<>();

            try
            {
                // Create a Scanner object that holds the file containing boats
                Scanner scan = new Scanner(boatFile);

                // This will loop as long there is something in the file
                while (scan.hasNext())
                {
                /* Create a new boat object and a String array that is separated by ","
                 * The array stores all the information on the relevant element */
                    Boat newBoat = new Boat();
                    String data = scan.nextLine();
                    String[] boatarray = data.split(",");
                    newBoat.setBoatOwnerId(Integer.parseInt(boatarray[0]));
                    newBoat.setBoatType(boatarray[1]);
                    newBoat.setBoatLength(Integer.parseInt(boatarray[2]));
                    newBoat.setBoatId(Integer.parseInt(boatarray[3]));

                    boatList.add(newBoat);
                }
            }
            catch (FileNotFoundException e)
            {
                e.printStackTrace();
            }
        }
    }

    /**
     * This will save all the boats to the file that contains boats
     */
    private void saveBoatFile()
    {
        try
        {
            // Create a PrintWriter object that hold the file containing boats
            PrintWriter printer = new PrintWriter(new FileOutputStream(new File(boatPath),false));

            // Iterate over the list and save the boats info to the file
            for(Boat b : boatList)
            {
                printer.print(b.getBoatOwnerId() + "," + b.getBoatType() + "," + b.getBoatLength() + "," + b.getBoatId() + "\n");
            }

            printer.close();
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * This will print out a list that contains members ID, name and number of boats
     * @return a StringBuilder containing compact information about member
     */
    public StringBuilder compactList()
    {
        StringBuilder str = new StringBuilder();

        // If file is empty this will print out
        if(memberFile.length() == 0)
        {
            str.append("No member is registered");
        }
        else
        {
            loadMemberFile();

            for(Member member : memberList)
            {
                str.append("- " + member.getId() + " " + member.getName());
                str.append("\n");

                if(!boatList.isEmpty())
                {
                    str.append("  " + member.getBoatList().size() + " boats");
                }
            }
        }

        return str;
    }

    /**
     * This will print out a list that contains members ID, name, ssn, boats and length of boats
     * @return a StringBuilder containing compact information about member
     */
    public StringBuilder verboseList()
    {
        StringBuilder str = new StringBuilder();

        // If file is empty this will print out
        if(memberFile.length() == 0)
        {
            str.append("No member is registered");
        }
        else
        {
            loadMemberFile();

            for(Member member : memberList)
            {
                str.append("- " + member.getId() + " " + member.getName() + " " + member.getSocialSecurityNumber());
                str.append("\n");

                if(!boatList.isEmpty())
                {
                    str.append(member.getBoatBelonging());
                }
            }
        }

        return str;
    }
}
