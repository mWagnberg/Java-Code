package View;

import Controller.BoatClubRegistry;
import Controller.CheckFunctions;
import Model.Boat;

import java.util.Scanner;

/**
 * Created by Michael Wagnberg and Patrik Hermansson on 2016-09-27.
 *
 * This class takes care of the user input and pass the input forward to the BoatClubRegistry class
 *
 */
public class Console
{
    /**
     * Create fields
     */
    private BoatClubRegistry reg = new BoatClubRegistry();
    private CheckFunctions check = new CheckFunctions();

    /**
     * This will show a menu that the user will choose what to do
     */
    public void showMainMenu()
    {
        System.out.println("**********************************************");
        System.out.println("*                  - Menu -                  *");
        System.out.println("*                                            *");
        System.out.println("* 1:  Show compact list                      *");
        System.out.println("* 2:  Show verbose list                      *");
        System.out.println("* 3:  Look at a specific members information *");
        System.out.println("* 4:  Add member                             *");
        System.out.println("* 5:  Change member                          *");
        System.out.println("* 6:  Delete member                          *");
        System.out.println("* 7:  Add boat                               *");
        System.out.println("* 8:  Change boat                            *");
        System.out.println("* 9:  Delete boat                            *");
        System.out.println("* 10: Quit                                   *");
        System.out.println("*                                            *");
        System.out.println("**********************************************");
        System.out.println("\nWhat do you want to do?");
        Scanner scan = new Scanner(System.in);
        String input = scan.nextLine();

        if(input.equals("1"))
        {
            showCompactList();
        }
        else if(input.equals("2"))
        {
            showVerboseList();
        }
        else if(input.equals("3"))
        {
            showMember();
        }
        else if(input.equals("4"))
        {
            showAddMember();
        }
        else if(input.equals("5"))
        {
            showChangeMember();
        }
        else if(input.equals("6"))
        {
            showDeleteMember();
        }
        else if(input.equals("7"))
        {
            showAddBoat();
        }
        else if (input.equals("8"))
        {
            showChangeBoat();
        }
        else if (input.equals("9"))
        {
            showDeleteBoat();
        }
        else if (input.equals("10"))
        {
            System.out.println("Thank you for your time, Bye!");
            System.exit(0);
        }
        else
        {
            System.out.println("No such alternative");
            showMainMenu();
        }
    }

    /**
     * This will show a specific members information when searching on a ID
     */
    public void showMember()
    {
        Scanner in = new Scanner(System.in);

        System.out.println("********** Look at a specific members information **********");
        System.out.println();
        System.out.println("This are the ID's and name of the registered members");
        System.out.println(check.printMemberList());

        System.out.println();
        System.out.println();

        System.out.println("Type in member ID to look at members information (Type 0 for main menu)");
        String input = in.nextLine();

        if(input.equals("0"))
        {
            showMainMenu();
        }
        // This will check if there's only integers in input
        if(check.checkLetters(input) == true)
        {
            System.out.println("ID should only contain integers");
            showMember();
        }

        // This will check if member exist in register
        if(check.checkIfMemberExist(input) == false)
        {
            System.out.println("Members does'nt exist");
            showMember();
        }

        // Call function to print out information about member
        reg.searchName(input);

        // Check if user wants to search again
        System.out.println("Search for another member? (yes/no)");
        input = in.nextLine();

        if(input.equals("yes"))
        {
            showMember();
        }
        else
        {
            showMainMenu();
        }
    }

    /**
     * This will take input from user and call the function addMember in BoatClubRegistry class
     */
    public void showAddMember()
    {
        Scanner in = new Scanner(System.in);

        System.out.println("*************************** Add Member ***************************");
        System.out.println();

        System.out.println("Type in name (Type 0 for main menu)");
        String name = in.nextLine();

        if(name.equals("0"))
        {
            showMainMenu();
        }
        // This will check if there's only characters in input
        if(check.checkLetters(name) == false)
        {
            System.out.println("Name should only contain letters");
            showAddMember();
        }

        System.out.println("Type in your Social Security Number: ");
        String ssn = in.nextLine();

        // This will check if there's only integers in input
        if(check.checkLetters(ssn) == true)
        {
            System.out.println("Personal Security Number should only contain numbers");
            showAddMember();
        }

        // Call the function in BoatClubRegistry class and take the inputs
        reg.addMember(name, ssn);

        // This will check if user wants to add a new member
        System.out.println("Add another member? (yes/no)");

        String answer = in.nextLine();

        if(answer.equals("yes"))
        {
            showAddMember();
        }
        else
        {
            showMainMenu();
        }
    }

    /**
     * This will take input from user and call the function deleteMember in BoatClubRegistry class
     */
    public void showDeleteMember()
    {
        System.out.println("*************************** Delete Member ***************************");
        System.out.println();
        System.out.println("This are the ID's and name of the registered members");
        System.out.println(check.printMemberList());

        System.out.println();
        System.out.println();

        System.out.println("Type in ID to remove member (Type 0 for main menu)");

        Scanner in = new Scanner(System.in);
        String answerID = in.nextLine();

        if(answerID.equals("0"))
        {
            showMainMenu();
        }
        // This will check if there's only integers in input
        if(check.checkLetters(answerID))
        {
            System.out.println("ID should only contain integers");
            showDeleteMember();
        }

        // This will check if member exist in register
        if(check.checkIfMemberExist(answerID) == false)
        {
            System.out.println("Members does'nt exist");
            showDeleteMember();
        }

        // Call the function deleteMember from the BoatClubRegistry class
        reg.deleteMember(answerID);

        // Check if user wants to delete another member
        System.out.println("Delete another member? (yes/no)");
        String answer = in.nextLine();

        if(answer.equals("yes"))
        {
            showDeleteMember();
        }
        else if(answer.equals("no"))
        {
            showMainMenu();
        }
    }

    /**
     * This will take input from user and call the function changeMember in BoatClubRegistry class
     */
    public void showChangeMember()
    {
        Scanner in = new Scanner(System.in);
        String answer = "";

        System.out.println("********************** Change Member **********************");
        System.out.println();
        System.out.println("This are the ID's and name of the registered members");
        System.out.println(check.printMemberList());

        System.out.println();
        System.out.println();

        System.out.println("Type in ID to change information about member (Type 0 for main menu)");
        String answerId = in.nextLine();

        if(answerId.equals("0"))
        {
            showMainMenu();
        }
        // This will check if there's only integers in input
        if(check.checkLetters(answerId))
        {
            System.out.println("ID should only contain integers");
            showChangeMember();
        }

        // This will check if member exist in register
        if(check.checkIfMemberExist(answerId) == false)
        {
            System.out.println("Members does'nt exist");
            showChangeMember();
        }

        System.out.println("What do you want to change?");
        System.out.println("1: Name\n2: Personal Number");
        int answerChange = in.nextInt();

        if(answerChange == 1)
        {
            System.out.println("Which name would you like to change to?");
            in.nextLine();
            answer = in.nextLine();
        }
        else if(answerChange == 2)
        {
            System.out.println("Which personal number would you like to change to?");
            in.nextLine();
            answer = in.nextLine();
        }

        // This will check if user pick a alternative that does'nt exist
        if(check.checkAlternativeInTwoWays(answerChange) == false)
        {
            System.out.println("No such alternative");
            showChangeMember();
        }

        // Call the function changeMember from the BoatClubRegistry class
        reg.changeMember(answerId, answerChange, answer);

        // Check if user wants to change anything else
        System.out.println("Change another member? (yes/no)");
        answer = in.nextLine();

        if(answer.equals("yes"))
        {
            showChangeMember();
        }
        else
        {
            showMainMenu();
        }
    }

    /**
     * This will take input from user and call the function addBoat in BoatClubRegistry class
     */
    public void showAddBoat()
    {
        Scanner in = new Scanner(System.in);

        System.out.println("*************************** Add Boat ***************************");
        System.out.println();
        System.out.println("This are the ID's and name of the registered members");
        System.out.println(check.printMemberList());

        System.out.println();
        System.out.println();

        System.out.println("What's your ID? (Type 0 for main menu)");
        String boatOwner = in.nextLine();

        if(boatOwner.equals("0"))
        {
            showMainMenu();
        }

        // This will check if there's only integers in input
        if(check.checkLetters(boatOwner) == true)
        {
            System.out.println("ID should only contain integers");
            showAddBoat();
        }

        // This will check if there's such a member registered
        if(check.checkIfMemberExist(boatOwner) == false)
        {
            System.out.println("Member does'nt exist in register");
            showAddBoat();
        }

        System.out.println("Which type of boat do you want to add?");
        System.out.println("1: Sailboat\n2: Motorsailer\n3: Kayak/Canoe\n4: Other");
        int boatType = in.nextInt();

        // This will check if user pick a alternative that does'nt exist
        if(check.checkAlternative(boatType) == false)
        {
            System.out.println("No such alternative");
            showAddBoat();
        }

        System.out.println("How long is the boat?");
        in.nextLine();
        String boatLength = in.nextLine();

        if(check.checkLetters(boatLength) == true)
        {
            System.out.println("Length should only contains integers");
            showAddBoat();
        }

        reg.addBoat(boatOwner, boatType, boatLength);

        // Check if user wants to add something else
        System.out.println("Add another boat? (yes/no)");
        String answer = in.nextLine();

        if(answer.equals("yes"))
        {
            showAddBoat();
        }
        else
        {
            showMainMenu();
        }
    }

    /**
     * This will take input from user and call the function deleteBoat in BoatClubRegistry class
     */
    public void showDeleteBoat()
    {
        Scanner in = new Scanner(System.in);

        System.out.println("*************************** Delete Boat ***************************");
        System.out.println();
        System.out.println("This are the ID's of registered boats and the owner ID of the boat");
        System.out.println(check.printBoatList());

        System.out.println();
        System.out.println();
        System.out.println("Type in your boats ID to remove boat (Type 0 for main menu)");
        String answerID = in.nextLine();

        if(answerID.equals("0"))
        {
            showMainMenu();
        }
        // This will check if there's only integers in input
        if(check.checkLetters(answerID) == true)
        {
            System.out.println("ID should only contain integers");
            showDeleteBoat();
        }

        // This will check if the boat which will be deleted is registered
        if(check.checkIfBoatExist(answerID) == false)
        {
            System.out.println("This boat ID is not registered");
            showDeleteBoat();
        }

        // This will call the function deleteBoat from the BoatClubRegistry class
        reg.deleteBoat(answerID);

        // Check if user wants to delete someone else
        System.out.println("Delete another boat? (yes/no)");
        String answer = in.nextLine();

        if(answer.equals("yes"))
        {
            showDeleteBoat();
        }
        else
        {
            showMainMenu();
        }
    }

    /**
     * This will take input from user and call the function changeBoat in BoatClubRegistry class
     */
    public void showChangeBoat()
    {
        Scanner in = new Scanner(System.in);

        System.out.println("*************************** Change Boat ***************************");
        System.out.println();
        System.out.println("This are the ID's of registered boats and the owner ID of the boat");
        System.out.println(check.printBoatList());

        System.out.println();
        System.out.println();

        System.out.println("Type in boat ID to change information (Type 0 for main menu)");
        String boatId = in.nextLine();

        if(boatId.equals("0"))
        {
            showMainMenu();
        }
        // This will check if there's only integers in input
        if(check.checkLetters(boatId) == true)
        {
            System.out.println("ID should only contain integers");
            showChangeBoat();
        }

        // This will check if the boat which will be changed is registered
        if(check.checkIfBoatExist(boatId) == false)
        {
            System.out.println("Boat does not exist in the register");
            showChangeBoat();
        }

        System.out.println("What do you want to change?");
        System.out.println("1: Boat type\n2: Boat length");
        int answerChange = in.nextInt();

        // This will check if user pick a alternative that does'nt exist
        if(check.checkAlternativeInTwoWays(answerChange) == false)
        {
            System.out.println("No such alternative");
            showChangeBoat();
        }

        int newInfo = 0;

        if(answerChange == 1)
        {
            System.out.println("Which boat type do you want to change it to?");
            System.out.println("1: Sailboat\n2: Motorsailer\n3: Kayak/Canoe\n4: Other");
            in.nextLine();
            newInfo = in.nextInt();
        }
        else if(answerChange == 2)
        {
            System.out.println("Which boat length do you want to change into?");
            in.nextLine();
            newInfo = in.nextInt();
        }

        // This will call the function changeBoat from the BoatClubRegistry class
        reg.changeBoat(boatId, answerChange, newInfo);

        // Check if user wants to change anything else
        System.out.println("Change another boat? (yes/no)");
        String answer = in.nextLine();

        if(answer.equals("yes"))
        {
            showChangeBoat();
        }
        else
        {
            showMainMenu();
        }
    }

    /**
     * This will call the function compactList from the BoatClubRegistry class which in turn print out the list containing
     * ID, name and number of boats
     */
    public void showCompactList()
    {
        System.out.println("**********************************************");
        System.out.println("*              - Compact List -              *");
        System.out.println("*                                            *");
        System.out.println("* ID | Name | Number of boats                *");
        System.out.println("*                                            *");

        System.out.println(reg.compactList());

        System.out.println("*                                            *");
        System.out.println("**********************************************");
        System.out.println();

        showMainMenu();
    }

    /**
     * This will call the function verboseList from the BoatClubRegistry class which in turn print out the list containing
     * ID, name, ssn, boat/boats and length of boat/boats
     */
    public void showVerboseList()
    {
        System.out.println("**********************************************");
        System.out.println("*              - Verbose List -              *");
        System.out.println("*                                            *");
        System.out.println("* ID | Name  | Social Security Number        *");
        System.out.println("* ID | Boat | Length                         *");
        System.out.println("*                                            *");

        System.out.println(reg.verboseList());

        System.out.println("*                                            *");
        System.out.println("**********************************************");
        System.out.println();

        showMainMenu();

    }
}
