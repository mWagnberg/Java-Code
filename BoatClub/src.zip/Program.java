import View.Console;

/**
 * Created by Michael on 2016-09-28.
 */
public class Program
{
    public static void main(String[] args)
    {
        Console c = new Console();
        c.showMainMenu();
    }
}
