package Model;

/**
 * Created by Michael Wagnberg and Patrik Hermansson on 2016-09-27.
 *
 * This class takes care about a boats information that's in the the boat club system.
 */
public class Boat
{
    /**
     * Create fields
     */
    private String boatType;
    private int boatLength;
    private int boatId;
    private int boatOwnerId;
    private int boatCounter;

    /**
     * When adding a new boat this get the boats id from the boat file
     * @return a integer the represents the already existing boats
     */
    public int getBoatCounter() {return boatCounter;}

    /**
     * When adding a new boat this sets the boats id
     * @param boatCounter is the id which the new boat is assigned
     */
    public void setBoatCounter(int boatCounter) {this.boatCounter = boatCounter;}

    /**
     * This gets the owner id of a boat
     * @return an integer containing the id of the owner of the boat
     */
    public int getBoatOwnerId() {
        return boatOwnerId;
    }

    /**
     * This sets the owner id of a boat
     * @param boatOwnerId is an integer that's sets the owner of the boat
     */
    public void setBoatOwnerId(int boatOwnerId) {
        this.boatOwnerId = boatOwnerId;
    }

    /**
     * This gets the type of boat
     * @return a String containing tha type of a boat
     */
    public String getBoatType()
    {
        return boatType;
    }

    /**
     * This sets the boat type
     * @param boatType is a String that's sets the boat type
     */
    public void setBoatType(String boatType)
    {
        this.boatType = boatType;
    }

    /**
     * This gets the length of a boat
     * @return a integer containing the length of the boat
     */
    public int getBoatLength()
    {
        return boatLength;
    }

    /**
     * This sets the length of a boat
     * @param boatLength is a integer that's sets the boat length
     */
    public void setBoatLength(int boatLength)
    {
        this.boatLength = boatLength;
    }

    /**
     * This gets the id of a boat
     * @return a integer containing the boat id
     */
    public int getBoatId()
    {
        return boatId;
    }

    /**
     * This sets the id of a boat
     * @param boatId is a integer that's sets the boat id
     */
    public void setBoatId(int boatId)
    {
        this.boatId = boatId;
    }
}
