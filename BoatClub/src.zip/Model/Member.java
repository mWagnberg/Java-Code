package Model;

import java.util.ArrayList;

/**
 * Created by Michael Wagnberg and Patrik Hermansson on 2016-09-27.
 *
 * This class takes care about a members information that's in the the boat club system.
 */
public class Member
{
    /**
     * Create fields
     */
    private int id;
    private String name;
    private String socialSecurityNumber;
    private ArrayList<Boat> boatList;
    private String boatBelonging;
    private int idCounter;

    /**
     * This get a string containing a members boat/boats and its length
     * @return a string of boats and respective length
     */
    public String getBoatBelonging()
    {
        return boatBelonging;
    }

    /**
     * This set boat type and length to a string
     * @param boatBelonging is the string containing boat type and length
     */
    public void setBoatBelonging(String boatBelonging)
    {
        this.boatBelonging = boatBelonging;
    }

    /**
     * When creating a new member this get the members id from the member file
     * @return a integer the represents the already existing members
     */
    public int getIdCounter() {
        return idCounter;
    }

    /**
     * When creating a new member this sets the members id
     * @param idCounter is the id which the new member is assigned
     */
    public void setIdCounter(int idCounter) {
        this.idCounter = idCounter;
    }

    /**
     * This gets a members id
     * @return a integer containing a members id
     */
    public int getId()
    {
        return id;
    }

    /**
     * This sets a members id
     * @param id is the integer that's sets a members id
     */
    public void setId(int id)
    {
        this.id = id;
    }

    /**
     * This gets a members name
     * @return a String containing a members name
     */
    public String getName()
    {
        return name;
    }

    /**
     * This sets a members name
     * @param name is a String that's sets a members name
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * This gets a members personal security number
     * @return a String containing a members personal security number
     */
    public String getSocialSecurityNumber()
    {
        return socialSecurityNumber;
    }

    /**
     * This sets a personal security number to a member
     * @param socialSecurityNumber is a String containing a members personal security number
     */
    public void setSocialSecurityNumber(String socialSecurityNumber)
    {
        this.socialSecurityNumber = socialSecurityNumber;
    }

    /**
     * This gets a list containing boats belonging to a member
     * @return an ArrayList of boats
     */
    public ArrayList<Boat> getBoatList()
    {
        return boatList;
    }

    /**
     * This sets a list of boats belonging to a member
     * @param boatList is the ArrayList of boats that's being set
     */
    public void setBoatList(ArrayList<Boat> boatList)
    {
        this.boatList = boatList;
    }
}
